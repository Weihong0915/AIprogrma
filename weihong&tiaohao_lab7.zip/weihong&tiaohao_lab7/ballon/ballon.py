# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 11:19:33 2022

@author: weih
"""
import pgzrun
import pygame
import pgzero
from pgzero.builtins import Actor
from random import randint
import smtplib, ssl
from pygame.locals import *



WIDTH = 800
HEIGHT = 600   #set up screen size

balloon = Actor("jet.png")   #create actor using ballon image
balloon.pos = 400, 300       #place the ballon in the center

bird = Actor("bird-up")      #set up actor bird
bird.pos = randint(800, 1600), randint(10, 200)  #x axis of bird is random from 800 to 1600, y is random from 10 to 200

bird2 = Actor("arrow100x100")      #set up actor bird
bird2.pos = randint(800, 1600), randint(10, 200)  #x axis of bird is random from 800 to 1600, y is random from 10 to 200

bird3 = Actor("airplane200x200")      #set up actor bird
bird.pos = randint(800, 1600), randint(10, 200)

house = Actor("house")       #set up the rest actor house and tree
house.pos = randint(800, 1600), 460

bird4 = Actor("bird-up")      #set up actor bird
bird4.pos = randint(800, 1600), randint(10, 200)  #x axis of bird is random from 800 to 1600, y is random from 10 to 200

tree = Actor("tree")
tree.pos = randint(800, 1600), 450

bird_up = True#when it is not game over keep bird actor
up = False         
game_over = False 
score = 0         #initial the base score
number_of_updates = 0   #initial game has been updated

scores = []        #set high scores array for the game

def update_high_scores():
    
    global score, scores
    filename = r"C:\Users\weiho\Desktop\SJSU Fall 2022\EE 104\weihong&tiaohao_lab7\ballon\high_scores.txt" #put high score data in this file
    scores = []
    with open(filename, "r") as file:#read high-score.txt
        line = file.readline()          #this reads the single line stored in file
        high_scores = line.split()      #splits high scores from horizontal to verticle
        for high_score in high_scores:  #order the high score  from highest to lowest
            if(score > int(high_score)):
                scores.append(str(score) + " ")  
                score = int(high_score)
            else:
                scores.append(str(high_score) + " ")
    with open(filename, "w") as file:  #write the new high scores into the txt
        for high_score in scores:
            file.write(high_score)

def display_high_scores():
    screen.draw.text("HIGH SCORES", (350, 150), color="black")
    y = 175  #set up first high score position
    position = 1
    for high_score in scores:
        screen.draw.text(str(position) + ". " + high_score, (350, y), color="black")
        y += 25
        position += 1

def draw():
    screen.blit("background", (0, 0))#background 
    if not game_over:#When game is not over, keep the actor
        balloon.draw()
        bird.draw()
        bird2.draw()
        bird3.draw()
        bird4.draw()
        house.draw()
        tree.draw()
        screen.draw.text("Score: " + str(score), (700, 5), color="black")  #show score on screen

    else:
        display_high_scores()          #
        
def on_mouse_down():#when mouse is not click,y go down
    global up
    up = True
    balloon.y -= 50
    
def on_mouse_up():#define go up when mouse click
    global up
    up = False
    
def flap():#make the bird wing flag with two picture
    global bird_up
    if bird_up:     #make the wing flap
        bird.image = "bird-down"
        bird4.image = "bird-down"
        bird_up = False
    else:
        bird.image = "bird-up"
        bird4.image = "bird-up"
        bird_up = True
        
def update(): #this make sure all the objest is keep appearing on the screen
    global game_over, score, number_of_updates
    if not game_over:
        if not up:
            balloon.y += 1  #this move the ballon down by one pixel
        #update for one bird   
        if bird.x > 0:  #bird move left
            bird.x -= 6
            if number_of_updates == 9:#call flap function
                flap()
                number_of_updates = 0
            else:
                number_of_updates += 1
        else:
            bird.x = randint(800, 1600)#make random position for the starting 
            bird.y = randint(10, 200)
            
            score += 1#calculate the score when the bird passed
            number_of_updates = 0

        if bird4.x > 0:#same concept on bird 4
            bird4.x -= 6
            if number_of_updates == 9:
                flap()
                number_of_updates = 0
            else:
                number_of_updates += 1
        elif bird4.collidepoint(bird.x, bird.y):
            bird4.x = randint(800, 1600)
            bird4.y = randint(10, 200)
        else:
            bird4.x = randint(800, 1600)
            bird4.y = randint(10, 200)
            score += 1
        #update for house 
        if house.right > 0:# use the same function of house
            house.x -= 4
        else:
            house.x = randint(800, 1600) 
            score += 1  #this line will update the score by one if the house moves off screen
        #update for tree
        if tree.right > 0:
            tree.x -= 4
        else:
            tree.x = randint(800, 1600)
            score += 1
            
        #update for arrow
        if bird2.right > 0: 
            bird2.x -= 10
        else:
            bird2.x = randint(800, 1600)
            bird2.y = randint(10, 200)
            score += 1
        #update for airplane
        if bird3.right > 0: 
           bird3.x += 1

        if balloon.top < 0 or balloon.bottom > 560: #if the ballon touched the top or bottom of screen
            game_over = True
            update_high_scores()
        if balloon.collidepoint(bird.x, bird.y) or \
            balloon.collidepoint(house.x, house.y) or \
                balloon.collidepoint(tree.x, tree.y) or \
                    balloon.collidepoint(bird2.x, bird2.y) or\
                        balloon.collidepoint(bird3.x, bird3.y):
                            game_over = True
                            update_high_scores()
                    
pgzrun.go()